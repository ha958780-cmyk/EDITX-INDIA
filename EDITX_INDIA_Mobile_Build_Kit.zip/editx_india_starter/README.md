# EDITX INDIA - Flutter Starter

This is a starter project for an Android-first video editing app.

## Included in this starter
- Dark themed home screen
- Template categories and search
- Favorites saved locally with SharedPreferences
- Template detail screen
- Gallery photo import
- Gallery video import and preview
- Basic text overlay preview
- Project aspect-ratio selector

## Not included yet
This is NOT a finished professional video editor. It does not yet render/export edited videos, trim clips, mix music, create transitions, or execute Alight Motion XML files. Those require a dedicated rendering/timeline implementation.

## Requirements
- Flutter SDK (stable channel)
- Android Studio
- Android SDK
- Android device or emulator

## Run
```bash
flutter pub get
flutter run
```

## Build Android APK
```bash
flutter build apk --release
```
APK output:
`build/app/outputs/flutter-apk/app-release.apk`

## Android permissions
The `image_picker` plugin uses Android's system photo picker/gallery flow. For video preview, `video_player` uses the Android platform video playback APIs.

## Suggested roadmap
1. Add a project model and local project saving.
2. Implement a multi-clip timeline.
3. Add trimming and clip ordering.
4. Add text/music/effects tracks.
5. Implement rendering/export with a maintained Android media-processing solution.
6. Add backend, accounts, template upload/download, moderation and creator profiles.

## Build an APK using only an Android phone (free route)

This project includes `.github/workflows/android-apk.yml`. Upload the project files to a GitHub repository, then open **Actions** → **Build EDITX INDIA APK** → **Run workflow**. When the run finishes, open the run and download the `EDITX-INDIA-debug-APK` artifact. Extract the downloaded artifact ZIP to get `app-debug.apk`.

The workflow creates the Android platform folder in the cloud, installs Flutter packages, and builds a debug APK for testing. It does not require Flutter or Android Studio to be installed on your phone. A public GitHub repository is the straightforward free route for Actions; public source code is visible to everyone. GitHub's usage and artifact limits can change, so check its current documentation.

This is a starter app APK, not yet a full professional video editor. Video rendering/export, trimming, music mixing, transitions, and a full timeline still need to be implemented.

For the easiest phone-only upload, upload this ZIP file to the root of your GitHub repository as `EDITX_INDIA_Mobile_Build_Kit.zip`. Then create the repository workflow at `.github/workflows/android-apk.yml` using the workflow file included in this ZIP (copy its contents into GitHub's **Add file → Create new file** editor). The workflow extracts the ZIP in the cloud and builds the test APK.
